# 垃圾扫描（只统计不删）

> ST 官方云端插件 · com.st.junk.scan v1.0.1

扫一遍常见垃圾目录：缩略图、缓存、日志、临时文件夹，列出各自占多大

## 用法

插件市场 → 本插件 → 打开页面，把文本粘进输入框，点「扫描」。
「反向↔」是相反方向的转换（有的话）。

## 权限

  * `ui.page`
  * `ui.theme`
  * `ui.toast`
  * `clipboard.read`
  * `clipboard.write`
  * `shell.exec`
  * `files.read`
  * `files.path`
  * `files.delete`

## 说明

全部逻辑都在插件自己的 `main.js` 里（纯 JS，不走网络、不依赖外部命令），
所以断网也能用。作者：ST 官方
