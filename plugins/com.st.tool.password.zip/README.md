# 随机密码生成

> ST 官方云端插件 · com.st.tool.password v1.0.1

生成 12 个高强度密码，并评估你输入那个的强度

## 用法

插件市场 → 本插件 → 打开页面，把文本粘进输入框，点「生成密码」。
「反向↔」是相反方向的转换（有的话）。

## 权限

  * `ui.page`
  * `ui.theme`
  * `ui.toast`
  * `clipboard.read`
  * `clipboard.write`

## 说明

全部逻辑都在插件自己的 `main.js` 里（纯 JS，不走网络、不依赖外部命令），
所以断网也能用。作者：ST 官方
