# 设备信息（原生）

> ST 官方云端插件 · com.st.sys.device v1.0.0

走宿主 API 拿机型、SDK、ABI、屏幕等，不依赖 shell

## 用法

插件市场 → 本插件 → 打开页面，把文本粘进输入框，点「读取」。
「反向↔」是相反方向的转换（有的话）。

## 权限

  * `ui.page`
  * `ui.theme`
  * `ui.toast`
  * `clipboard.read`
  * `clipboard.write`
  * `device.info`
  * `battery.info`
  * `storage.info`

## 说明

全部逻辑都在插件自己的 `main.js` 里（纯 JS，不走网络、不依赖外部命令），
所以断网也能用。作者：ST 官方
