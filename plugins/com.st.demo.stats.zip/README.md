# 目录统计（示例插件 02）

演示**纯脚本插件**：没有 HTML、没有 JS，只有一个 `run.sh`。

## 它能干什么

在插件市场里点「运行脚本」，它会统计**宿主当前所在的目录**：

- 文件数 / 目录数 / 总大小 / 该分区剩余空间
- 最大的 5 个文件
- 扩展名分布 Top 10

输出会一边执行一边回显在宿主的对话框里。

## 只申请了一条权限

```json
"permissions": ["shell.exec"]
```

这是刻意做的最小化示范：**`shell.exec` 是脚本能不能跑的唯一门槛**。
脚本动文件靠的是 shell 自己，不需要 `files.read` / `files.write` 那些页面 API 的权限。
想以 root / shell 身份跑，再额外写 `shell.priv`（用户会看到红色高危提示）。

## 宿主给你的环境变量

| 变量 | 内容 |
|---|---|
| `ST_CURRENT_DIR` | 宿主当前目录，脚本靠它知道从哪开始统计 |
| `ST_SELECTED` | 选中项，换行分隔 |
| `ST_SELECTED_COUNT` | 选中数量 |
| `ST_PLUGIN_ID` / `ST_PLUGIN_NAME` / `ST_PLUGIN_VERSION` / `ST_PLUGIN_DIR` | 插件自身信息 |
| `ST_THEME` | 当前主题名 |
| `ST_API_LEVEL` | 宿主插件 API 版本 |
| `ST_CLIPBOARD` | 剪贴板内容；没授 `clipboard.read` 时是空串 |

## 脚本编写约定

1. **第一行写 `#!/system/bin/sh`**（宿主虽然自己指定了解释器，但留着方便你本地调试）
2. `stdout` 正常输出，`stderr` 会以另一种颜色显示
3. `exit 0` 表示成功，非 0 会在界面上标成失败
4. 有 30 秒超时（`PluginScriptRunner.DEFAULT_TIMEOUT`），长任务请拆批或自己加 `-t` 判断
5. 输出超过 512KB 会被截断，别 `cat` 大文件

## 改成你自己的

```sh
# 只想统计图片
find "$ST_CURRENT_DIR" -type f \( -name '*.jpg' -o -name '*.png' \) | wc -l

# 需要 root 才能读的目录
if [ "${ST_PRIV_MODE:-none}" != "none" ]; then
    ls -la /data/local/tmp
fi
```

> `ST_PRIV_MODE` 只有在插件授了 `shell.priv` 且手机上真的连着 root/Shizuku 时才不是 `none`。
