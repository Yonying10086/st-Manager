#!/system/bin/sh
# ---------------------------------------------------------------------------
# 目录统计 —— 纯脚本插件示例
#
# 宿主做的事：
#   1. 检查插件有没有 shell.exec / shell.priv / shell.terminal 之一
#   2. 注入 ST_* 环境变量
#   3. 用 /system/bin/sh 跑这个文件，把 stdout / stderr 实时回显到界面上
#
# 只用 toybox 自带的基础命令（find / du / df / awk / sort / head），
# 不依赖 root，也不依赖 GNU 扩展参数，Android 7~15 都能跑。
# ---------------------------------------------------------------------------

DIR="${ST_CURRENT_DIR:-/sdcard}"

echo "插件：${ST_PLUGIN_NAME:-?} v${ST_PLUGIN_VERSION:-?}  (API ${ST_API_LEVEL:-?})"
echo "主题：${ST_THEME:-?}"
echo "目录：$DIR"
echo "----------------------------------------"

if [ ! -d "$DIR" ]; then
    echo "目录不存在或不可读：$DIR"
    exit 1
fi

# ---------- 总览 ----------
FILES=$(find "$DIR" -type f 2>/dev/null | wc -l | tr -d ' ')
DIRS=$(find "$DIR" -type d 2>/dev/null | wc -l | tr -d ' ')

echo "文件数：$FILES"
echo "目录数：$DIRS"

TOTAL=$(du -sh "$DIR" 2>/dev/null | awk '{print $1}')
[ -z "$TOTAL" ] && TOTAL="?"
echo "总大小：$TOTAL"

FREE=$(df -h "$DIR" 2>/dev/null | awk 'NR==2{print $4" 可用 / "$2" 总量"}')
[ -n "$FREE" ] && echo "剩余空间：$FREE"

# ---------- 选中项（本脚本不处理，只报数） ----------
if [ -n "${ST_SELECTED:-}" ]; then
    echo "----------------------------------------"
    echo "另有 ${ST_SELECTED_COUNT:-0} 个选中项"
fi

# ---------- 最大的 5 个文件 ----------
echo "----------------------------------------"
echo "最大的 5 个文件："
du -ak "$DIR" 2>/dev/null | sort -rn | head -40 | while IFS="$(printf '\t')" read -r KB P; do
    [ -z "$P" ] && continue
    [ -f "$P" ] || continue
    printf '  %8s  %s\n' "$(du -h "$P" 2>/dev/null | awk '{print $1}')" "$P"
done | head -5

# ---------- 扩展名 Top 10 ----------
echo "----------------------------------------"
echo "扩展名分布 Top 10："

find "$DIR" -type f 2>/dev/null \
    | awk '
        {
            n = split($0, part, "/")
            name = part[n]
            if (name == "") next
            dot = 0
            for (i = length(name); i > 0; i--) {
                if (substr(name, i, 1) == ".") { dot = i; break }
            }
            if (dot > 1 && dot < length(name)) {
                ext = "." tolower(substr(name, dot + 1))
            } else {
                ext = "(无扩展名)"
            }
            count[ext]++
        }
        END {
            for (e in count) printf "%d\t%s\n", count[e], e
        }
    ' \
    | sort -rn \
    | head -10 \
    | awk -F"$(printf '\t')" '{ printf "  %6d 个  %s\n", $1, $2 }'

echo "----------------------------------------"
echo "完成"
exit 0
