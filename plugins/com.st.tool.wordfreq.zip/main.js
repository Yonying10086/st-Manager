
/* ST 官方插件运行时 —— 所有插件共用，插件只需提供 forward / backward 两个函数 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var inEl = $('input'), outEl = $('out');

  function hasST() { return !!(window.ST && typeof window.ST.api === 'number'); }

  // ---------- 主题 ----------
  try {
    var t = hasST() && ST.theme ? ST.theme : null;
    if (t) {
      var r = document.documentElement.style;
      if (t.accent) r.setProperty('--accent', t.accent);
      if (t.bg) { r.setProperty('--bg', t.bg); r.setProperty('--surface', t.bg); }
      if (t.text) { r.setProperty('--text', t.text); }
      if (t.dark) { r.setProperty('--surface', 'rgba(127,127,127,.14)'); r.setProperty('--line', 'rgba(255,255,255,.14)'); }
    }
  } catch (e) {}

  // ---------- 通用编解码工具 ----------
  var U = {
    b64enc: function (s) { return btoa(unescape(encodeURIComponent(s))); },
    b64dec: function (s) {
      return decodeURIComponent(escape(atob(String(s).replace(/\s+/g, ''))));
    },
    hex: function (s) {
      var out = [], i;
      for (i = 0; i < s.length; i++) {
        var c = s.charCodeAt(i).toString(16);
        while (c.length < 4) c = '0' + c;
        out.push(c);
      }
      return out.join(' ');
    },
    unhex: function (s) {
      var parts = String(s).replace(/0x/gi, ' ').replace(/[^0-9a-fA-F]/g, ' ').trim().split(/\s+/);
      var out = '';
      for (var i = 0; i < parts.length; i++) {
        if (!parts[i]) continue;
        if (parts[i].length <= 2) {
          // 字节流：按 UTF-8 还原
          var bytes = [];
          for (var k = 0; k < parts.length; k++) if (parts[k]) bytes.push(parseInt(parts[k], 16) & 0xFF);
          try {
            let s2 = '';
            for (var b = 0; b < bytes.length; b++) s2 += '%' + ('0' + bytes[b].toString(16)).slice(-2);
            return decodeURIComponent(s2);
          } catch (e) { return bytes.map(function (x) { return String.fromCharCode(x); }).join(''); }
        }
        out += String.fromCharCode(parseInt(parts[i], 16));
      }
      return out;
    },
    // ---- MD5 ----
    md5: function (s) {
      var T = [
        3614090360, 3905402710, 606105819, 3250441966, 4118548399, 1200080426, 2821735955, 4249261313,
        1770035416, 2336552879, 4294925233, 2304563134, 1804603682, 4254626195, 2792965006, 1236535329,
        4129170786, 3225465664, 643717713, 3921069994, 3593408605, 38016083, 3634488961, 3889429448,
        568446438, 3275163606, 4107603335, 1163531501, 2850285829, 4243563512, 1735328473, 2368359562,
        4294588738, 2272392833, 1839030562, 4259657740, 2763975236, 1272893353, 4139469664, 3200236656,
        681279174, 3936430074, 3572445317, 76029189, 3654602809, 3873151461, 530742520, 3299628645,
        4096336452, 1126891415, 2878612391, 4237533241, 1700485571, 2399980690, 4293915773, 2240044497,
        1873313359, 4264355552, 2734768916, 1309151649, 4149444226, 3174756917, 718787259, 3951481745
      ];
      var S = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
      var bytes = unescape(encodeURIComponent(s));
      var len = bytes.length;
      var nBlocks = Math.floor((len + 8) / 64) + 1;
      var words = [];
      for (var i = 0; i < nBlocks * 16; i++) words[i] = 0;
      for (i = 0; i < len; i++) words[i >> 2] |= (bytes.charCodeAt(i) & 0xff) << ((i % 4) * 8);
      words[len >> 2] |= 0x80 << ((len % 4) * 8);
      words[nBlocks * 16 - 2] = (len * 8) | 0;
      var a = 0x67452301, b = 0xefcdab89, c = 0x98badcfe, d = 0x10325476;
      for (var blk = 0; blk < nBlocks; blk++) {
        var base = blk * 16;
        var A = a, B = b, C = c, D = d;
        for (var r = 0; r < 64; r++) {
          var F, g;
          if (r < 16) { F = (B & C) | (~B & D); g = r; }
          else if (r < 32) { F = (D & B) | (~D & C); g = (5 * r + 1) % 16; }
          else if (r < 48) { F = B ^ C ^ D; g = (3 * r + 5) % 16; }
          else { F = C ^ (B | ~D); g = (7 * r) % 16; }
          var tmp = D;
          D = C;
          C = B;
          var sum = (A + F + T[r] + words[base + g]) | 0;
          B = (B + ((sum << S[r]) | (sum >>> (32 - S[r])))) | 0;
          A = tmp;
        }
        a = (a + A) | 0; b = (b + B) | 0; c = (c + C) | 0; d = (d + D) | 0;
      }
      function w2h(x) {
        var out = '', k, t;
        for (k = 0; k < 4; k++) {
          t = (x >>> (k * 8)) & 0xff;
          out += ('0' + t.toString(16)).slice(-2);
        }
        return out;
      }
      return w2h(a) + w2h(b) + w2h(c) + w2h(d);
    },
    // ---- SHA-1 ----
    sha1: function (s) {
      var str = unescape(encodeURIComponent(s));
      var ml = str.length * 8, words = [], i, j;
      for (i = 0; i < str.length; i++) words[i >> 2] = (words[i >> 2] || 0) | (str.charCodeAt(i) << (24 - (i % 4) * 8));
      words[str.length >> 2] = (words[str.length >> 2] || 0) | (0x80 << (24 - (str.length % 4) * 8));
      var n = ((str.length + 8) >> 6) * 16 + 16;
      for (i = 0; i < n; i++) if (!words[i]) words[i] = 0;
      words[n - 1] = ml;
      var H0 = 0x67452301, H1 = 0xEFCDAB89, H2 = 0x98BADCFE, H3 = 0x10325476, H4 = 0xC3D2E1F0;
      function rotl(x, n2) { return (x << n2) | (x >>> (32 - n2)); }
      for (i = 0; i < n; i += 16) {
        var w = [], a = H0, b = H1, c = H2, d = H3, e = H4, f, k, tmp;
        for (j = 0; j < 80; j++) {
          if (j < 16) w[j] = words[i + j] | 0;
          else w[j] = rotl(w[j - 3] ^ w[j - 8] ^ w[j - 14] ^ w[j - 16], 1);
          if (j < 20) { f = (b & c) | (~b & d); k = 0x5A827999; }
          else if (j < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1; }
          else if (j < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC; }
          else { f = b ^ c ^ d; k = 0xCA62C1D6; }
          tmp = (rotl(a, 5) + f + e + k + w[j]) | 0;
          e = d; d = c; c = rotl(b, 30); b = a; a = tmp;
        }
        H0 = (H0 + a) | 0; H1 = (H1 + b) | 0; H2 = (H2 + c) | 0; H3 = (H3 + d) | 0; H4 = (H4 + e) | 0;
      }
      function hx(x) { var out = '', t; for (t = 28; t >= 0; t -= 4) out += ((x >> t) & 15).toString(16); return out; }
      return hx(H0) + hx(H1) + hx(H2) + hx(H3) + hx(H4);
    },
    // ---- SHA-256 ----
    sha256: function (s) {
      var K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
      var str = unescape(encodeURIComponent(s));
      var words = [], i, j;
      for (i = 0; i < str.length; i++) words[i >> 2] = (words[i >> 2] || 0) | (str.charCodeAt(i) << (24 - (i % 4) * 8));
      words[str.length >> 2] = (words[str.length >> 2] || 0) | (0x80 << (24 - (str.length % 4) * 8));
      var n = ((str.length + 8) >> 6) * 16 + 16;
      for (i = 0; i < n; i++) if (!words[i]) words[i] = 0;
      words[n - 1] = str.length * 8;
      var H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
      function rr(x, n2) { return (x >>> n2) | (x << (32 - n2)); }
      for (i = 0; i < n; i += 16) {
        var w = [], a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
        for (j = 0; j < 64; j++) {
          if (j < 16) w[j] = words[i + j] | 0;
          else {
            var s0 = rr(w[j - 15], 7) ^ rr(w[j - 15], 18) ^ (w[j - 15] >>> 3);
            var s1 = rr(w[j - 2], 17) ^ rr(w[j - 2], 19) ^ (w[j - 2] >>> 10);
            w[j] = (w[j - 16] + s0 + w[j - 7] + s1) | 0;
          }
          var S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25);
          var ch = (e & f) ^ (~e & g);
          var t1 = (h + S1 + ch + K[j] + w[j]) | 0;
          var S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22);
          var mj = (a & b) ^ (a & c) ^ (b & c);
          var t2 = (S0 + mj) | 0;
          h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
        }
        H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
        H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
      }
      return H.map(function (x) { return ('00000000' + (x >>> 0).toString(16)).slice(-8); }).join('');
    },
    crc32: function (s) {
      var str = unescape(encodeURIComponent(s)), c, crc = 0xFFFFFFFF, i, k;
      for (i = 0; i < str.length; i++) {
        c = (crc ^ str.charCodeAt(i)) & 0xFF;
        for (k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xEDB88320 : c >>> 1;
        crc = (crc >>> 8) ^ c;
      }
      return ('00000000' + ((crc ^ 0xFFFFFFFF) >>> 0).toString(16)).slice(-8);
    }
  };

  // ---------- 插件定义 ----------
  // 本运行时的 IIFE 先执行，__ST_OPS__ 是在文件后半段才赋值的；
  // 所以绝不能缓存成 var OPS = window.__ST_OPS__ || {}，否则永远是空对象，
  // 表现就是「点任何按钮都提示不支持反向操作」。
  function getOps() { return window.__ST_OPS__ || {}; }

  function render(fn, raw) {
    var text = raw;
    try {
      var res = fn(text);
      if (res === undefined || res === null) res = '';
      outEl.textContent = String(res);
      return String(res);
    } catch (e) {
      outEl.textContent = '出错：' + (e && e.message ? e.message : e) + '\n\n检查输入格式是否正确。';
      return null;
    }
  }

  /** 异步操作（翻译、HTTP）：ops.forwardAsync(text, cb) */
  function renderAsync(fn, raw) {
    outEl.textContent = '请求中…';
    try {
      fn(raw, function (res) {
        outEl.textContent = (res === undefined || res === null) ? '' : String(res);
      });
    } catch (e) {
      outEl.textContent = '出错：' + (e && e.message ? e.message : e);
    }
    return null;
  }

  function run(dir) {
    var text = inEl.value;
    var ops0 = getOps();
    if (!text) {
      // 只读 / 扫描 / 清理类插件本来就没有输入，允许空着点
      var optional = (dir > 0 ? ops0.allowEmpty === true : ops0.allowEmptyBack === true);
      if (!optional && hasST() && ST.clipboard && dir > 0) {
        var c = ST.clipboard.get();
        if (c) { inEl.value = c; text = c; }
      }
      if (!text && !optional) { if (hasST()) ST.toast('先粘贴或输入内容'); return; }
    }
    var ops = ops0;
    if (dir > 0 && ops.forwardAsync) { renderAsync(ops.forwardAsync, text); return; }
    var fn = dir > 0 ? ops.forward : ops.backward;
    if (!fn) {
      if (hasST()) {
        ST.toast(dir > 0 ? '这个插件没有正向操作（插件包不完整）' : '这个插件不支持反向操作');
      }
      return;
    }
    var got = render(fn, text);
    if (got !== null && dir < 0) inEl.value = got;
  }

  $('go').addEventListener('click', function () { run(1); });
  $('swap').addEventListener('click', function () { run(-1); });
  $('copy').addEventListener('click', function () {
    var v = outEl.textContent || '';
    if (hasST() && ST.clipboard) { ST.clipboard.set(v); ST.toast('已复制'); }
    else { try { navigator.clipboard.writeText(v); } catch (e) {} }
  });
  $('save').addEventListener('click', function () {
    var v = outEl.textContent || '';
    if (!hasST()) { outEl.textContent = '不在宿主里，无法保存'; return; }
    var dir = ST.getPath ? ST.getPath() : '/sdcard';
    ST.input({ title: '保存文件名', hint: '例如 result.txt', value: getOps().saveName || 'result.txt' },
      function (r) {
        if (!r || !r.ok || !r.text) return;
        var path = dir + '/' + r.text;
        var res = ST.writeText(path, v);
        if (res === true) ST.toast('已保存：' + path); else ST.toast('保存失败：' + (res && res.error ? res.error : res));
      });
  });

  // 启动时把宿主选中的文件内容读进来（文件型插件会把 OPS.loadPath 设为 true）
  if (hasST() && getOps().loadSelected && ST.getSelected && ST.readText) {
    try {
      var sel = ST.getSelected();
      if (sel && sel.length) {
        var body = ST.readText(sel[0]);
        if (typeof body === 'string') { inEl.value = body; }
      }
    } catch (e) {}
  }

  window.__ST_U__ = U;
})();


/* ---- 本插件的转换逻辑 ---- */
window.__ST_OPS__ = (function (U) {
  var ops = {"saveName": "words.txt"};
  ops.forward = function (s) {
  var m={};
  (s.toLowerCase().match(/[a-z0-9_]{2,}/g)||[]).forEach(function(w){ m[w]=(m[w]||0)+1; });
  (s.match(/[\u4e00-\u9fa5]{2}/g)||[]).forEach(function(w){ m[w]=(m[w]||0)+1; });
  var arr=[]; for(var k in m) arr.push([k,m[k]]);
  arr.sort(function(a,b){return b[1]-a[1];});
  return arr.slice(0,50).map(function(x,i){ return (i+1)+'. '+x[0]+'  ×'+x[1]; }).join('\n');
};
  return ops;
})(window.__ST_U__);
