# 翻译（多接口自动回退）

> ST 官方云端插件 · com.st.net.translate2 v1.0.1

Google / MyMemory / Lingva 三路轮询，一个不通自动换下一个

## 用法

插件市场 → 本插件 → 打开页面，把文本粘进输入框，点「翻译」。
「反向↔」是相反方向的转换（有的话）。

## 权限

  * `ui.page`
  * `ui.theme`
  * `ui.toast`
  * `clipboard.read`
  * `clipboard.write`
  * `net.http`

## 说明

全部逻辑都在插件自己的 `main.js` 里（纯 JS，不走网络、不依赖外部命令），
所以断网也能用。作者：ST 官方
