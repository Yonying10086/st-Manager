#!/system/bin/sh
# 空目录清理：递归找出当前目录下的空文件夹并删除
DIR="${ST_CURRENT_DIR:-/sdcard}"
echo "扫描空目录：$DIR"
find "$DIR" -type d -empty -print 2>/dev/null | head -200
echo "----- 以上为空目录（示例插件不会直接删除）-----"