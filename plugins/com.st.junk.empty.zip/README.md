# 空目录清道夫

> ST 官方云端插件 · com.st.junk.empty v1.0.1

递归删掉所有空文件夹，删到不再产生新的空目录为止

## 用法

插件市场 → 本插件 → 打开页面，把文本粘进输入框，点「清理空目录」。
「反向↔」是相反方向的转换（有的话）。

## 权限

  * `ui.page`
  * `ui.theme`
  * `ui.toast`
  * `clipboard.read`
  * `clipboard.write`
  * `shell.exec`
  * `files.read`
  * `files.path`
  * `files.delete`

## 说明

全部逻辑都在插件自己的 `main.js` 里（纯 JS，不走网络、不依赖外部命令），
所以断网也能用。作者：ST 官方
