# 已冻结应用列表

> ST 官方云端插件 · com.st.sys.frozen v1.0.1

列出所有被停用（disabled）的应用，附包名，方便解冻

## 用法

插件市场 → 本插件 → 打开页面，把文本粘进输入框，点「列出已冻结」。
「反向↔」是相反方向的转换（有的话）。

## 权限

  * `ui.page`
  * `ui.theme`
  * `ui.toast`
  * `clipboard.read`
  * `clipboard.write`
  * `shell.exec`
  * `shell.priv`
  * `files.read`
  * `files.path`

## 说明

全部逻辑都在插件自己的 `main.js` 里（纯 JS，不走网络、不依赖外部命令），
所以断网也能用。作者：ST 官方
