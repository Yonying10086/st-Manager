# 压缩当前目录

> ST 官方云端插件 · com.st.file.ziphere v1.0.1

把当前目录整个压成 zip 放到上一级，进度有提示

## 用法

插件市场 → 本插件 → 打开页面，把文本粘进输入框，点「压缩」。
「反向↔」是相反方向的转换（有的话）。

## 权限

  * `ui.page`
  * `ui.theme`
  * `ui.toast`
  * `clipboard.read`
  * `clipboard.write`
  * `files.read`
  * `files.write`
  * `files.path`
  * `files.create`
  * `files.archive`

## 说明

全部逻辑都在插件自己的 `main.js` 里（纯 JS，不走网络、不依赖外部命令），
所以断网也能用。作者：ST 官方
