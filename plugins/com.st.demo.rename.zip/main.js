/*
 * 批量重命名 —— 页面插件示例
 *
 * 这个文件只干一件事：把宿主里勾选的文件按「前缀 + 补零序号 + 扩展名」改名。
 * 所有能力都来自 window.ST（宿主注入的桥），插件自己碰不到文件系统。
 *
 * 约定：ST.xxx 失败时返回 { error: "中文原因" }，成功时返回真正的值。
 * 所以每个返回值都要先判断是不是错误对象，别直接当字符串用。
 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var logEl = $('log');
  var selected = [];

  // ------------------------------------------------------------------
  // 基础工具
  // ------------------------------------------------------------------

  /** 是不是在宿主里跑（用浏览器直接打开 page.html 调试时为 false） */
  function hasST() {
    return !!(window.ST && typeof window.ST.api === 'number');
  }

  /** 追加一行日志 */
  function log(msg) {
    var d = new Date();
    var t = ('0' + d.getHours()).slice(-2) + ':' +
            ('0' + d.getMinutes()).slice(-2) + ':' +
            ('0' + d.getSeconds()).slice(-2);
    logEl.textContent += '\n[' + t + '] ' + msg;
    logEl.scrollTop = logEl.scrollHeight;
  }

  /** 是不是错误对象 */
  function isErr(v) {
    return v && typeof v === 'object' && typeof v.error === 'string';
  }

  /** 取文件名（不含目录） */
  function baseName(p) {
    var i = Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\'));
    return i >= 0 ? p.slice(i + 1) : p;
  }

  /** 取扩展名（含点），没有就返回空串 */
  function extName(name) {
    var i = name.lastIndexOf('.');
    if (i <= 0 || i === name.length - 1) return '';
    return name.slice(i);
  }

  /** 数字补零 */
  function padNum(n, w) {
    var s = String(n);
    while (s.length < w) s = '0' + s;
    return s;
  }

  // ------------------------------------------------------------------
  // 主题：把宿主的颜色搬进 CSS 变量
  // ------------------------------------------------------------------

  function applyTheme() {
    if (!hasST() || !ST.theme) return;
    var t = ST.theme;
    var s = document.documentElement.style;
    if (t.bg) s.setProperty('--bg', t.bg);
    if (t.text) s.setProperty('--text', t.text);
    if (t.dim) s.setProperty('--dim', t.dim);
    if (t.surface) s.setProperty('--surface', t.surface);
    if (t.accent) s.setProperty('--accent', t.accent);
    s.setProperty('--line', t.isDark ? 'rgba(255,255,255,.10)' : 'rgba(0,0,0,.08)');
  }

  // ------------------------------------------------------------------
  // 选中项
  // ------------------------------------------------------------------

  function loadSelected() {
    if (!hasST() || !ST.getSelected) {
      $('sel').textContent = '不在宿主里运行，读不到选中项。';
      return;
    }
    var v = ST.getSelected();
    selected = Array.isArray(v) ? v : [];
    if (!selected.length) {
      $('sel').textContent =
        '当前没有勾选文件 —— 回主界面长按勾几个文件，再从这里打开我。';
      return;
    }
    var lines = selected.slice(0, 5).map(function (p) { return '  ' + p; }).join('\n');
    $('sel').textContent = '已勾选 ' + selected.length + ' 个：\n' + lines +
      (selected.length > 5 ? '\n  …还有 ' + (selected.length - 5) + ' 个' : '');
  }

  // ------------------------------------------------------------------
  // 主流程
  // ------------------------------------------------------------------

  function doRename() {
    if (!hasST()) {
      log('不在宿主里，跳过');
      return;
    }
    if (!selected.length) {
      ST.toast('先在文件列表里勾选文件');
      return;
    }
    if (!ST.hasPermission('files.rename')) {
      log('缺少 files.rename 权限 —— 去 插件市场 → 本插件 → 权限 里授予后重试');
      ST.toast('没有改名权限');
      return;
    }

    var prefix = $('prefix').value || '';
    var start = parseInt($('start').value, 10);
    if (!isFinite(start)) start = 1;
    var pad = parseInt($('pad').value, 10);
    if (!isFinite(pad) || pad < 1) pad = 3;
    if (pad > 6) pad = 6;
    var keepExt = $('keepExt').checked;

    var ok = 0, fail = 0, idx = start;
    log('开始处理 ' + selected.length + ' 个文件…');

    for (var i = 0; i < selected.length; i++) {
      var path = selected[i];
      var name = baseName(path);
      if (!name) { log('跳过（路径异常）：' + path); fail++; continue; }

      var ext = keepExt ? extName(name) : '';
      var newName = prefix + padNum(idx, pad) + ext;
      var r = ST.rename(path, newName);

      if (isErr(r)) {
        log('失败 ' + name + ' → ' + newName + '：' + r.error);
        fail++;
      } else {
        log('OK   ' + name + ' → ' + newName);
        ok++;
      }
      idx++;
    }

    log('完成：成功 ' + ok + ' 个，失败 ' + fail + ' 个');
    if (ST.toast) ST.toast('改名完成：成功 ' + ok + ' / 失败 ' + fail);
    if (ST.log) ST.log('rename done ok=' + ok + ' fail=' + fail);
  }

  // ------------------------------------------------------------------
  // 绑定
  // ------------------------------------------------------------------

  $('go').addEventListener('click', doRename);
  $('refresh').addEventListener('click', function () {
    loadSelected();
    log('已重新读取选中项');
  });

  applyTheme();
  loadSelected();
  if (hasST()) {
    log('就绪 · 宿主 API ' + ST.api + ' · 插件 ' + (ST.plugin ? ST.plugin.name : '?'));
  } else {
    log('没检测到 window.ST —— 你现在是在普通浏览器里打开的吧？');
  }
})();
