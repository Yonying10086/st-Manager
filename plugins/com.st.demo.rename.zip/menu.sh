#!/system/bin/sh
# ---------------------------------------------------------------------------
# 文件长按菜单钩子示例：给每个选中的文件加「_YYYYmmdd_HHMMSS」后缀
#
# 宿主会把下面这些变量注入环境，脚本直接用就行：
#   ST_SELECTED        选中的绝对路径，换行分隔
#   ST_SELECTED_COUNT  选中数量
#   ST_CURRENT_DIR     当前目录
#   ST_PLUGIN_ID / ST_PLUGIN_NAME / ST_PLUGIN_VERSION / ST_PLUGIN_DIR
#   ST_THEME / ST_API_LEVEL / ST_CLIPBOARD（无 clipboard.read 权限时为空）
#
# 注意：脚本以「普通应用身份」跑（shell.exec），只能动应用有权限的目录。
# 想动 /data 下的东西，除了 shell.priv 权限，手机上还得真的连着 root 或 Shizuku。
# ---------------------------------------------------------------------------

if [ -z "${ST_SELECTED:-}" ]; then
    echo "没有选中任何文件"
    exit 2
fi

TS=$(date +%Y%m%d_%H%M%S)
echo "时间戳：$TS"
echo "插件：${ST_PLUGIN_NAME:-?} v${ST_PLUGIN_VERSION:-?}"
echo "----------------------------------------"

# 把换行分隔的列表拆成位置参数（不用管道，避免 subshell 里改不了计数）
OLDIFS=$IFS
IFS='
'
set -- $ST_SELECTED
IFS=$OLDIFS

OK=0
FAIL=0

for SRC in "$@"; do
    [ -z "$SRC" ] && continue

    if [ ! -e "$SRC" ]; then
        echo "跳过（不存在）: $SRC"
        FAIL=$((FAIL + 1))
        continue
    fi

    DIR=$(dirname "$SRC")
    BASE=$(basename "$SRC")

    case "$BASE" in
        *.*)
            STEM=${BASE%.*}
            EXT=.${BASE##*.}
            ;;
        *)
            STEM=$BASE
            EXT=""
            ;;
    esac

    DST="$DIR/${STEM}_${TS}${EXT}"

    if [ -e "$DST" ]; then
        echo "跳过（目标已存在）: $(basename "$DST")"
        FAIL=$((FAIL + 1))
        continue
    fi

    if mv -f "$SRC" "$DST" 2>/dev/null; then
        echo "OK   $BASE -> $(basename "$DST")"
        OK=$((OK + 1))
    else
        echo "失败 $BASE（权限不足？）"
        FAIL=$((FAIL + 1))
    fi
done

echo "----------------------------------------"
echo "完成：成功 $OK 个，失败 $FAIL 个"

if [ "$OK" -eq 0 ]; then
    exit 1
fi
exit 0
