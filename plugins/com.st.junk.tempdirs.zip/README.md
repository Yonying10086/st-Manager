# 破文件夹清理

> ST 官方云端插件 · com.st.junk.tempdirs v1.0.1

递归找出 .temp/.tmp/temp/tmp/.cache/.trash 这类垃圾目录，确认后连目录一起删

## 用法

插件市场 → 本插件 → 打开页面，把文本粘进输入框，点「扫描并删除」。
「反向↔」是相反方向的转换（有的话）。

## 权限

  * `ui.page`
  * `ui.theme`
  * `ui.toast`
  * `clipboard.read`
  * `clipboard.write`
  * `shell.exec`
  * `files.read`
  * `files.path`
  * `files.delete`

## 说明

全部逻辑都在插件自己的 `main.js` 里（纯 JS，不走网络、不依赖外部命令），
所以断网也能用。作者：ST 官方
