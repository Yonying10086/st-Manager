#!/system/bin/sh
# 设备信息面板
echo "型号: $(getprop ro.product.model)"
echo "品牌: $(getprop ro.product.brand)"
echo "Android: $(getprop ro.build.version.release) (SDK $(getprop ro.build.version.sdk))"
echo "ABI: $(getprop ro.product.cpu.abi)"
echo "内核: $(uname -r)"