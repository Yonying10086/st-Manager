
/* ST 官方插件运行时 —— 所有插件共用，插件只需提供 forward / backward 两个函数 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var inEl = $('input'), outEl = $('out');

  function hasST() { return !!(window.ST && typeof window.ST.api === 'number'); }

  // ---------- 主题 ----------
  try {
    var t = hasST() && ST.theme ? ST.theme : null;
    if (t) {
      var r = document.documentElement.style;
      if (t.accent) r.setProperty('--accent', t.accent);
      if (t.bg) { r.setProperty('--bg', t.bg); r.setProperty('--surface', t.bg); }
      if (t.text) { r.setProperty('--text', t.text); }
      if (t.dark) { r.setProperty('--surface', 'rgba(127,127,127,.14)'); r.setProperty('--line', 'rgba(255,255,255,.14)'); }
    }
  } catch (e) {}

  // ---------- 通用编解码工具 ----------
  var U = {
    b64enc: function (s) { return btoa(unescape(encodeURIComponent(s))); },
    b64dec: function (s) {
      return decodeURIComponent(escape(atob(String(s).replace(/\s+/g, ''))));
    },
    hex: function (s) {
      var out = [], i;
      for (i = 0; i < s.length; i++) {
        var c = s.charCodeAt(i).toString(16);
        while (c.length < 4) c = '0' + c;
        out.push(c);
      }
      return out.join(' ');
    },
    unhex: function (s) {
      var parts = String(s).replace(/0x/gi, ' ').replace(/[^0-9a-fA-F]/g, ' ').trim().split(/\s+/);
      var out = '';
      for (var i = 0; i < parts.length; i++) {
        if (!parts[i]) continue;
        if (parts[i].length <= 2) {
          // 字节流：按 UTF-8 还原
          var bytes = [];
          for (var k = 0; k < parts.length; k++) if (parts[k]) bytes.push(parseInt(parts[k], 16) & 0xFF);
          try {
            let s2 = '';
            for (var b = 0; b < bytes.length; b++) s2 += '%' + ('0' + bytes[b].toString(16)).slice(-2);
            return decodeURIComponent(s2);
          } catch (e) { return bytes.map(function (x) { return String.fromCharCode(x); }).join(''); }
        }
        out += String.fromCharCode(parseInt(parts[i], 16));
      }
      return out;
    },
    // ---- MD5 ----
    md5: function (s) {
      var T = [
        3614090360, 3905402710, 606105819, 3250441966, 4118548399, 1200080426, 2821735955, 4249261313,
        1770035416, 2336552879, 4294925233, 2304563134, 1804603682, 4254626195, 2792965006, 1236535329,
        4129170786, 3225465664, 643717713, 3921069994, 3593408605, 38016083, 3634488961, 3889429448,
        568446438, 3275163606, 4107603335, 1163531501, 2850285829, 4243563512, 1735328473, 2368359562,
        4294588738, 2272392833, 1839030562, 4259657740, 2763975236, 1272893353, 4139469664, 3200236656,
        681279174, 3936430074, 3572445317, 76029189, 3654602809, 3873151461, 530742520, 3299628645,
        4096336452, 1126891415, 2878612391, 4237533241, 1700485571, 2399980690, 4293915773, 2240044497,
        1873313359, 4264355552, 2734768916, 1309151649, 4149444226, 3174756917, 718787259, 3951481745
      ];
      var S = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
      var bytes = unescape(encodeURIComponent(s));
      var len = bytes.length;
      var nBlocks = Math.floor((len + 8) / 64) + 1;
      var words = [];
      for (var i = 0; i < nBlocks * 16; i++) words[i] = 0;
      for (i = 0; i < len; i++) words[i >> 2] |= (bytes.charCodeAt(i) & 0xff) << ((i % 4) * 8);
      words[len >> 2] |= 0x80 << ((len % 4) * 8);
      words[nBlocks * 16 - 2] = (len * 8) | 0;
      var a = 0x67452301, b = 0xefcdab89, c = 0x98badcfe, d = 0x10325476;
      for (var blk = 0; blk < nBlocks; blk++) {
        var base = blk * 16;
        var A = a, B = b, C = c, D = d;
        for (var r = 0; r < 64; r++) {
          var F, g;
          if (r < 16) { F = (B & C) | (~B & D); g = r; }
          else if (r < 32) { F = (D & B) | (~D & C); g = (5 * r + 1) % 16; }
          else if (r < 48) { F = B ^ C ^ D; g = (3 * r + 5) % 16; }
          else { F = C ^ (B | ~D); g = (7 * r) % 16; }
          var tmp = D;
          D = C;
          C = B;
          var sum = (A + F + T[r] + words[base + g]) | 0;
          B = (B + ((sum << S[r]) | (sum >>> (32 - S[r])))) | 0;
          A = tmp;
        }
        a = (a + A) | 0; b = (b + B) | 0; c = (c + C) | 0; d = (d + D) | 0;
      }
      function w2h(x) {
        var out = '', k, t;
        for (k = 0; k < 4; k++) {
          t = (x >>> (k * 8)) & 0xff;
          out += ('0' + t.toString(16)).slice(-2);
        }
        return out;
      }
      return w2h(a) + w2h(b) + w2h(c) + w2h(d);
    },
    // ---- SHA-1 ----
    sha1: function (s) {
      var str = unescape(encodeURIComponent(s));
      var ml = str.length * 8, words = [], i, j;
      for (i = 0; i < str.length; i++) words[i >> 2] = (words[i >> 2] || 0) | (str.charCodeAt(i) << (24 - (i % 4) * 8));
      words[str.length >> 2] = (words[str.length >> 2] || 0) | (0x80 << (24 - (str.length % 4) * 8));
      var n = ((str.length + 8) >> 6) * 16 + 16;
      for (i = 0; i < n; i++) if (!words[i]) words[i] = 0;
      words[n - 1] = ml;
      var H0 = 0x67452301, H1 = 0xEFCDAB89, H2 = 0x98BADCFE, H3 = 0x10325476, H4 = 0xC3D2E1F0;
      function rotl(x, n2) { return (x << n2) | (x >>> (32 - n2)); }
      for (i = 0; i < n; i += 16) {
        var w = [], a = H0, b = H1, c = H2, d = H3, e = H4, f, k, tmp;
        for (j = 0; j < 80; j++) {
          if (j < 16) w[j] = words[i + j] | 0;
          else w[j] = rotl(w[j - 3] ^ w[j - 8] ^ w[j - 14] ^ w[j - 16], 1);
          if (j < 20) { f = (b & c) | (~b & d); k = 0x5A827999; }
          else if (j < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1; }
          else if (j < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC; }
          else { f = b ^ c ^ d; k = 0xCA62C1D6; }
          tmp = (rotl(a, 5) + f + e + k + w[j]) | 0;
          e = d; d = c; c = rotl(b, 30); b = a; a = tmp;
        }
        H0 = (H0 + a) | 0; H1 = (H1 + b) | 0; H2 = (H2 + c) | 0; H3 = (H3 + d) | 0; H4 = (H4 + e) | 0;
      }
      function hx(x) { var out = '', t; for (t = 28; t >= 0; t -= 4) out += ((x >> t) & 15).toString(16); return out; }
      return hx(H0) + hx(H1) + hx(H2) + hx(H3) + hx(H4);
    },
    // ---- SHA-256 ----
    sha256: function (s) {
      var K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
      var str = unescape(encodeURIComponent(s));
      var words = [], i, j;
      for (i = 0; i < str.length; i++) words[i >> 2] = (words[i >> 2] || 0) | (str.charCodeAt(i) << (24 - (i % 4) * 8));
      words[str.length >> 2] = (words[str.length >> 2] || 0) | (0x80 << (24 - (str.length % 4) * 8));
      var n = ((str.length + 8) >> 6) * 16 + 16;
      for (i = 0; i < n; i++) if (!words[i]) words[i] = 0;
      words[n - 1] = str.length * 8;
      var H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
      function rr(x, n2) { return (x >>> n2) | (x << (32 - n2)); }
      for (i = 0; i < n; i += 16) {
        var w = [], a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
        for (j = 0; j < 64; j++) {
          if (j < 16) w[j] = words[i + j] | 0;
          else {
            var s0 = rr(w[j - 15], 7) ^ rr(w[j - 15], 18) ^ (w[j - 15] >>> 3);
            var s1 = rr(w[j - 2], 17) ^ rr(w[j - 2], 19) ^ (w[j - 2] >>> 10);
            w[j] = (w[j - 16] + s0 + w[j - 7] + s1) | 0;
          }
          var S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25);
          var ch = (e & f) ^ (~e & g);
          var t1 = (h + S1 + ch + K[j] + w[j]) | 0;
          var S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22);
          var mj = (a & b) ^ (a & c) ^ (b & c);
          var t2 = (S0 + mj) | 0;
          h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
        }
        H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
        H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
      }
      return H.map(function (x) { return ('00000000' + (x >>> 0).toString(16)).slice(-8); }).join('');
    },
    crc32: function (s) {
      var str = unescape(encodeURIComponent(s)), c, crc = 0xFFFFFFFF, i, k;
      for (i = 0; i < str.length; i++) {
        c = (crc ^ str.charCodeAt(i)) & 0xFF;
        for (k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xEDB88320 : c >>> 1;
        crc = (crc >>> 8) ^ c;
      }
      return ('00000000' + ((crc ^ 0xFFFFFFFF) >>> 0).toString(16)).slice(-8);
    }
  };

  // ---------- 插件定义 ----------
  // 本运行时的 IIFE 先执行，__ST_OPS__ 是在文件后半段才赋值的；
  // 所以绝不能缓存成 var OPS = window.__ST_OPS__ || {}，否则永远是空对象，
  // 表现就是「点任何按钮都提示不支持反向操作」。
  function getOps() { return window.__ST_OPS__ || {}; }

  function render(fn, raw) {
    var text = raw;
    try {
      var res = fn(text);
      if (res === undefined || res === null) res = '';
      outEl.textContent = String(res);
      return String(res);
    } catch (e) {
      outEl.textContent = '出错：' + (e && e.message ? e.message : e) + '\n\n检查输入格式是否正确。';
      return null;
    }
  }

  /** 异步操作（翻译、HTTP）：ops.forwardAsync(text, cb) */
  function renderAsync(fn, raw) {
    outEl.textContent = '请求中…';
    try {
      fn(raw, function (res) {
        outEl.textContent = (res === undefined || res === null) ? '' : String(res);
      });
    } catch (e) {
      outEl.textContent = '出错：' + (e && e.message ? e.message : e);
    }
    return null;
  }

  function run(dir) {
    var text = inEl.value;
    var ops0 = getOps();
    if (!text) {
      // 只读 / 扫描 / 清理类插件本来就没有输入，允许空着点
      var optional = (dir > 0 ? ops0.allowEmpty === true : ops0.allowEmptyBack === true);
      if (!optional && hasST() && ST.clipboard && dir > 0) {
        var c = ST.clipboard.get();
        if (c) { inEl.value = c; text = c; }
      }
      if (!text && !optional) { if (hasST()) ST.toast('先粘贴或输入内容'); return; }
    }
    var ops = ops0;
    var asyncFn = dir > 0 ? ops.forwardAsync : ops.backwardAsync;
    if (asyncFn) { renderAsync(asyncFn, text); return; }
    var fn = dir > 0 ? ops.forward : ops.backward;
    if (!fn) {
      if (hasST()) {
        ST.toast(dir > 0 ? '这个插件没有正向操作（插件包不完整）' : '这个插件不支持反向操作');
      }
      return;
    }
    var got = render(fn, text);
    if (got !== null && dir < 0) inEl.value = got;
  }

  $('go').addEventListener('click', function () { run(1); });
  $('swap').addEventListener('click', function () { run(-1); });
  $('copy').addEventListener('click', function () {
    var v = outEl.textContent || '';
    if (hasST() && ST.clipboard) { ST.clipboard.set(v); ST.toast('已复制'); }
    else { try { navigator.clipboard.writeText(v); } catch (e) {} }
  });
  $('save').addEventListener('click', function () {
    var v = outEl.textContent || '';
    if (!hasST()) { outEl.textContent = '不在宿主里，无法保存'; return; }
    var dir = ST.getPath ? ST.getPath() : '/sdcard';
    ST.input({ title: '保存文件名', hint: '例如 result.txt', value: getOps().saveName || 'result.txt' },
      function (r) {
        if (!r || !r.ok || !r.text) return;
        var path = dir + '/' + r.text;
        var res = ST.writeText(path, v);
        if (res === true) ST.toast('已保存：' + path); else ST.toast('保存失败：' + (res && res.error ? res.error : res));
      });
  });

  // 启动时把宿主选中的文件内容读进来（文件型插件会把 OPS.loadPath 设为 true）
  if (hasST() && getOps().loadSelected && ST.getSelected && ST.readText) {
    try {
      var sel = ST.getSelected();
      if (sel && sel.length) {
        var body = ST.readText(sel[0]);
        if (typeof body === 'string') { inEl.value = body; }
      }
    } catch (e) {}
  }

  window.__ST_U__ = U;
})();


/* ---- 本插件的转换逻辑 ---- */
window.__ST_OPS__ = (function (U) {
  var ops = {"saveName": "qrcode.txt"};
  ops.forward = function (s) {
  var text = String(s || '');
  if (!text) throw new Error('先输入要变成二维码的内容');
  if (text.length > 600) throw new Error('内容太长了，二维码最多放几百个字节，短链接/文本比较合适');
  // ---- 内置二维码编码器（byte 模式，ECC L，版本 1-15 自动） ----
/* 极简 QR 编码器（byte 模式，ECC 级别 L/M，版本 1-15 自动）
 * 对外：qrMatrix(text, level) -> 二维数组（0/1），边长 = version*4+17
 * 说明：只做 byte 模式，够生成链接、文本、电话、wifi 之类的码。
 */
var QR = (function () {
  // 版本 -> 级别 -> [[块数, 每块总码字, 每块数据码字], ...]
  var BLOCKS = {
    1: { L: [[1, 26, 19]], M: [[1, 26, 16]] },
    2: { L: [[1, 44, 34]], M: [[1, 44, 28]] },
    3: { L: [[1, 70, 55]], M: [[1, 70, 44]] },
    4: { L: [[1, 100, 80]], M: [[2, 50, 32]] },
    5: { L: [[1, 134, 108]], M: [[2, 67, 43]] },
    6: { L: [[2, 86, 68]], M: [[4, 43, 27]] },
    7: { L: [[2, 98, 78]], M: [[4, 49, 31]] },
    8: { L: [[2, 121, 97]], M: [[2, 60, 38], [2, 61, 39]] },
    9: { L: [[2, 146, 116]], M: [[3, 58, 36], [2, 59, 37]] },
    10: { L: [[2, 86, 68], [2, 87, 69]], M: [[4, 69, 43], [1, 70, 44]] },
    11: { L: [[4, 101, 81]], M: [[1, 80, 50], [4, 81, 51]] },
    12: { L: [[2, 116, 92], [2, 117, 93]], M: [[6, 58, 36], [2, 59, 37]] },
    13: { L: [[4, 133, 107]], M: [[8, 59, 37], [1, 60, 38]] },
    14: { L: [[3, 145, 115], [1, 146, 116]], M: [[4, 64, 40], [5, 65, 41]] },
    15: { L: [[5, 109, 87], [1, 110, 88]], M: [[5, 65, 41], [5, 66, 42]] }
  };
  var ALIGN = {
    1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34],
    7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50],
    11: [6, 30, 54], 12: [6, 32, 58], 13: [6, 34, 62], 14: [6, 26, 46, 66],
    15: [6, 26, 48, 70]
  };

  // ---- GF(256) ----
  var EXP = new Array(512), LOG = new Array(256);
  (function () {
    var x = 1;
    for (var i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; }
    for (var j = 255; j < 512; j++) EXP[j] = EXP[j - 255];
  })();
  function mul(a, b) { return (a === 0 || b === 0) ? 0 : EXP[LOG[a] + LOG[b]]; }

  function genPoly(n) {
    var g = [1];
    for (var i = 0; i < n; i++) {
      var ng = new Array(g.length + 1);
      for (var k = 0; k < ng.length; k++) ng[k] = 0;
      for (var j = 0; j < g.length; j++) {
        ng[j] ^= mul(g[j], EXP[i]);   // g * x^0 term shifted
        ng[j + 1] ^= g[j];            // g * x^1
      }
      g = ng;
    }
    return g;
  }

  function ecc(data, n) {
    var g = genPoly(n);
    var res = new Array(n);
    for (var i = 0; i < n; i++) res[i] = 0;
    for (var i2 = 0; i2 < data.length; i2++) {
      var factor = data[i2] ^ res[0];
      for (var j = 0; j < n - 1; j++) res[j] = res[j + 1] ^ mul(factor, g[n - 1 - j]);
      res[n - 1] = mul(factor, g[0]);
    }
    return res;
  }

  function dataCapacity(ver, level) {
    var total = 0, gs = BLOCKS[ver][level];
    for (var i = 0; i < gs.length; i++) total += gs[i][0] * gs[i][2];
    return total;
  }

  function utf8Bytes(s) {
    var out = [], i, c;
    for (i = 0; i < s.length; i++) {
      c = s.charCodeAt(i);
      if (c < 0x80) out.push(c);
      else if (c < 0x800) { out.push(0xc0 | (c >> 6), 0x80 | (c & 63)); }
      else if (c >= 0xd800 && c <= 0xdbff && i + 1 < s.length) {
        var c2 = s.charCodeAt(i + 1);
        var cp = 0x10000 + ((c - 0xd800) << 10) + (c2 - 0xdc00);
        out.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 63), 0x80 | ((cp >> 6) & 63), 0x80 | (cp & 63));
        i++;
      } else { out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63)); }
    }
    return out;
  }

  function pickVersion(len, level) {
    for (var v = 1; v <= 15; v++) {
      if (!BLOCKS[v][level]) continue;
      var countBits = v <= 9 ? 8 : 16;
      if (len >= (1 << countBits)) continue;
      var need = 4 + countBits + len * 8;
      if (need <= dataCapacity(v, level) * 8) return v;
    }
    return -1;
  }

  function buildCodewords(bytes, ver, level) {
    var countBits = ver <= 9 ? 8 : 16;
    var bits = [];
    function put(val, n) { for (var i = n - 1; i >= 0; i--) bits.push((val >> i) & 1); }
    put(4, 4);                      // byte 模式
    put(bytes.length, countBits);
    for (var i = 0; i < bytes.length; i++) put(bytes[i], 8);
    var capBits = dataCapacity(ver, level) * 8;
    for (var t = 0; t < 4 && bits.length < capBits; t++) bits.push(0);
    while (bits.length % 8) bits.push(0);
    var words = [];
    for (var b = 0; b < bits.length; b += 8) {
      var w = 0;
      for (var k = 0; k < 8; k++) w = (w << 1) | bits[b + k];
      words.push(w);
    }
    var pad = [0xec, 0x11], pi = 0;
    while (words.length < dataCapacity(ver, level)) { words.push(pad[pi % 2]); pi++; }

    // 分块 + 纠错
    var gs = BLOCKS[ver][level], blocks = [], pos = 0;
    for (var gi = 0; gi < gs.length; gi++) {
      var nb = gs[gi][0], tot = gs[gi][1], nd = gs[gi][2], ecn = tot - nd;
      for (var n = 0; n < nb; n++) {
        var d = words.slice(pos, pos + nd);
        pos += nd;
        blocks.push({ data: d, ec: ecc(d, ecn) });
      }
    }
    // 交织
    var out = [], maxD = 0, k2, i2;
    for (i2 = 0; i2 < blocks.length; i2++) maxD = Math.max(maxD, blocks[i2].data.length);
    for (i2 = 0; i2 < maxD; i2++) {
      for (k2 = 0; k2 < blocks.length; k2++) {
        if (i2 < blocks[k2].data.length) out.push(blocks[k2].data[i2]);
      }
    }
    var ecLen = blocks[0].ec.length;
    for (i2 = 0; i2 < ecLen; i2++) {
      for (k2 = 0; k2 < blocks.length; k2++) out.push(blocks[k2].ec[i2]);
    }
    return out;
  }

  function makeMatrix(ver) {
    var size = ver * 4 + 17, m = [], reserved = [];
    for (var i = 0; i < size; i++) {
      m.push(new Array(size));
      reserved.push(new Array(size));
      for (var j = 0; j < size; j++) { m[i][j] = 0; reserved[i][j] = false; }
    }
    function setF(x, y, v) {
      if (x < 0 || y < 0 || x >= size || y >= size) return;
      m[y][x] = v; reserved[y][x] = true;
    }
    // 定位图形
    var pos = [[0, 0], [size - 7, 0], [0, size - 7]];
    for (var p = 0; p < 3; p++) {
      var ox = pos[p][0], oy = pos[p][1];
      for (var dy = -1; dy <= 7; dy++) {
        for (var dx = -1; dx <= 7; dx++) {
          var x = ox + dx, y = oy + dy;
          if (x < 0 || y < 0 || x >= size || y >= size) continue;
          var inner = (dx >= 0 && dx <= 6 && dy >= 0 && dy <= 6);
          var dark = inner && ((dx === 0 || dx === 6 || dy === 0 || dy === 6) ||
                               (dx >= 2 && dx <= 4 && dy >= 2 && dy <= 4));
          setF(x, y, dark ? 1 : 0);
        }
      }
    }
    // 定时图形
    for (var t = 8; t < size - 8; t++) {
      setF(t, 6, t % 2 === 0 ? 1 : 0);
      setF(6, t, t % 2 === 0 ? 1 : 0);
    }
    // 校正图形
    var al = ALIGN[ver];
    for (var a = 0; a < al.length; a++) {
      for (var b = 0; b < al.length; b++) {
        var cx = al[a], cy = al[b];
        if ((cx === 6 && cy === 6) || (cx === 6 && cy === size - 7) || (cx === size - 7 && cy === 6)) continue;
        for (var ey = -2; ey <= 2; ey++) {
          for (var ex = -2; ex <= 2; ex++) {
            var d2 = Math.max(Math.abs(ex), Math.abs(ey));
            setF(cx + ex, cy + ey, (d2 === 1) ? 0 : 1);
          }
        }
      }
    }
    // 格式信息占位 + 版本信息占位（先标记保留）
    for (var i3 = 0; i3 < 9; i3++) {
      if (i3 !== 6) { setF(i3, 8, 0); setF(8, i3, 0); }
    }
    setF(8, 8, 0);
    for (var i4 = 0; i4 < 8; i4++) { setF(size - 1 - i4, 8, 0); setF(8, size - 1 - i4, 0); }
    if (ver >= 7) {
      for (var i5 = 0; i5 < 6; i5++) {
        for (var j5 = 0; j5 < 3; j5++) {
          setF(size - 11 + j5, i5, 0);
          setF(i5, size - 11 + j5, 0);
        }
      }
    }
    return { m: m, res: reserved, size: size, setF: setF };
  }

  function placeData(mtx, codewords, mask) {
    var size = mtx.size, m = mtx.m, res = mtx.res;
    var bitIdx = 0, total = codewords.length * 8;
    function bitAt(i) {
      if (i >= total) return 0;
      return (codewords[i >> 3] >> (7 - (i & 7))) & 1;
    }
    var up = true;
    for (var x = size - 1; x > 0; x -= 2) {
      if (x === 6) x = 5;
      for (var k = 0; k < size; k++) {
        var y = up ? size - 1 - k : k;
        for (var dd = 0; dd < 2; dd++) {
          var xx = x - dd;
          if (res[y][xx]) continue;
          var bit = bitAt(bitIdx++);
          if (maskFn(mask, xx, y)) bit ^= 1;
          m[y][xx] = bit;
        }
      }
      up = !up;
    }
  }

  function maskFn(mask, x, y) {
    switch (mask) {
      case 0: return (x + y) % 2 === 0;
      case 1: return y % 2 === 0;
      case 2: return x % 3 === 0;
      case 3: return (x + y) % 3 === 0;
      case 4: return (Math.floor(y / 2) + Math.floor(x / 3)) % 2 === 0;
      case 5: return ((x * y) % 2) + ((x * y) % 3) === 0;
      case 6: return (((x * y) % 2) + ((x * y) % 3)) % 2 === 0;
      case 7: return (((x + y) % 2) + ((x * y) % 3)) % 2 === 0;
    }
    return false;
  }

  function bch15(data) {
    var d = data << 10;
    while (bitLen(d) - 11 >= 0) d ^= 0x537 << (bitLen(d) - 11);
    return ((data << 10) | d) ^ 0x5412;
  }
  function bitLen(v) { var n = 0; while (v) { n++; v >>= 1; } return n; }

  function bch18(data) {
    var d = data << 12;
    while (bitLen(d) - 13 >= 0) d ^= 0x1f25 << (bitLen(d) - 13);
    return (data << 12) | d;
  }

  function drawFormat(mtx, level, mask) {
    var lvlBits = { L: 1, M: 0, Q: 3, H: 2 }[level];
    var fmt = bch15((lvlBits << 3) | mask);
    var size = mtx.size, m = mtx.m, res = mtx.res;
    for (var i = 0; i <= 5; i++) setFmt(8, i, (fmt >> i) & 1);
    setFmt(8, 7, (fmt >> 6) & 1);
    setFmt(8, 8, (fmt >> 7) & 1);
    setFmt(7, 8, (fmt >> 8) & 1);
    for (var j = 9; j <= 14; j++) setFmt(14 - j, 8, (fmt >> j) & 1);
    for (var k = 0; k <= 7; k++) setFmt(size - 1 - k, 8, (fmt >> k) & 1);
    for (var l = 8; l <= 14; l++) setFmt(8, size - 15 + l, (fmt >> l) & 1);
    setFmt(8, size - 8, 1); // 固定暗模块
    function setFmt(x, y, v) { m[y][x] = v; res[y][x] = true; }
  }

  function drawVersion(mtx, ver) {
    if (ver < 7) return;
    var size = mtx.size, m = mtx.m, res = mtx.res;
    var bits = bch18(ver);
    for (var i = 0; i < 18; i++) {
      var b = (bits >> i) & 1;
      var a = Math.floor(i / 3), c = i % 3;
      m[size - 11 + c][a] = b; res[size - 11 + c][a] = true;
      m[a][size - 11 + c] = b; res[a][size - 11 + c] = true;
    }
  }

  function penalty(m, size) {
    var score = 0, i, j, run, dark = 0;
    for (i = 0; i < size; i++) {
      run = 1;
      for (j = 1; j < size; j++) {
        if (m[i][j] === m[i][j - 1]) { run++; if (run === 5) score += 3; else if (run > 5) score++; }
        else run = 1;
      }
      run = 1;
      for (j = 1; j < size; j++) {
        if (m[j][i] === m[j - 1][i]) { run++; if (run === 5) score += 3; else if (run > 5) score++; }
        else run = 1;
      }
    }
    for (i = 0; i < size - 1; i++) {
      for (j = 0; j < size - 1; j++) {
        var v = m[i][j];
        if (v === m[i][j + 1] && v === m[i + 1][j] && v === m[i + 1][j + 1]) score += 3;
      }
    }
    var pat = [1, 0, 1, 1, 1, 0, 1];
    for (i = 0; i < size; i++) {
      for (j = 0; j <= size - 7; j++) {
        var okH = true, okV = true;
        for (var k = 0; k < 7; k++) {
          if (m[i][j + k] !== pat[k]) okH = false;
          if (m[j + k][i] !== pat[k]) okV = false;
        }
        if (okH) score += 40;
        if (okV) score += 40;
      }
    }
    for (i = 0; i < size; i++) for (j = 0; j < size; j++) if (m[i][j]) dark++;
    var ratio = dark * 100 / (size * size);
    score += Math.floor(Math.abs(ratio - 50) / 5) * 10;
    return score;
  }

  function qrMatrix(text, level, forcedMask, forcedVersion) {
    level = level === 'M' ? 'M' : 'L';
    var bytes = utf8Bytes(String(text));
    var ver = forcedVersion || pickVersion(bytes.length, level);
    if (ver < 0) throw new Error('内容太长了（最多约 ' + dataCapacity(15, level) + ' 字节以内）');
    var cw = buildCodewords(bytes, ver, level);

    if (typeof forcedMask === 'number') {
      var one = makeMatrix(ver);
      drawVersion(one, ver);
      placeData(one, cw, forcedMask);
      drawFormat(one, level, forcedMask);
      return one.m;
    }

    var best = null, bestScore = Infinity;
    for (var mask = 0; mask < 8; mask++) {
      var mtx = makeMatrix(ver);
      drawVersion(mtx, ver);
      placeData(mtx, cw, mask);
      drawFormat(mtx, level, mask);
      var sc = penalty(mtx.m, mtx.size);
      if (sc < bestScore) { bestScore = sc; best = mtx.m; }
    }
    return best;
  }

  return { matrix: qrMatrix, version: function (t, l) { return pickVersion(utf8Bytes(String(t)).length, l === 'M' ? 'M' : 'L'); } };
})();
if (typeof module !== 'undefined') module.exports = QR;

  // ---- 画成字符画 ----
  var m = QR.matrix(text, 'L');
  var n = m.length, qz = 2, rows = [];
  for (var y = -qz; y < n + qz; y += 2) {
    var line = '', x;
    for (x = -qz; x < n + qz; x++) {
      var top = (y >= 0 && y < n && x >= 0 && x < n) ? m[y][x] : 0;
      var bot = (y + 1 >= 0 && y + 1 < n && x >= 0 && x < n) ? m[y + 1][x] : 0;
      line += top && bot ? '\u2588' : top ? '\u2580' : bot ? '\u2584' : ' ';
    }
    rows.push(line);
  }
  var ver = QR.version(text, 'L');
  return '二维码　版本 ' + ver + '　' + n + '×' + n + '　（内容 ' + text.length + ' 字符）\n\n'
    + rows.join('\n')
    + '\n\n直接截图给对方扫；或者点「保存」写成 txt，字体换成等宽也能扫。';
};
  return ops;
})(window.__ST_U__);
