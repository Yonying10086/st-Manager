# 已安装应用清单

> ST 官方云端插件 · com.st.sys.apps v1.0.0

列出应用数量与前 30 个包名，找包名时很方便

## 用法

插件市场 → 本插件 → 打开页面，把文本粘进输入框，点「列出应用」。
「反向↔」是相反方向的转换（有的话）。

## 权限

  * `ui.page`
  * `ui.theme`
  * `ui.toast`
  * `clipboard.read`
  * `clipboard.write`
  * `app.info`

## 说明

全部逻辑都在插件自己的 `main.js` 里（纯 JS，不走网络、不依赖外部命令），
所以断网也能用。作者：ST 官方
