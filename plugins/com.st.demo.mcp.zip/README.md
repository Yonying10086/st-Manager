# MCP 工具台（示例插件 03）

演示插件怎么**借宿主已经做好的 AI 工具**干活。

## 它能干什么

| 按钮 | 调的工具 | 效果 |
|---|---|---|
| ① 列出全部可用工具 | `ST.mcp.tools()` | 把 30 个工具的名单打印出来 |
| ② 列目录 | `fs_list` | 输入路径 → 显示目录内容 |
| ③ 看文件信息 | `fs_stat` | 显示大小、时间、权限、类型 |
| ④ 设备信息 | `device_info` | 品牌、型号、系统、ABI、存储、电量 |

## 只申请了 `mcp.bridge` 一条能力性权限

```json
"permissions": ["mcp.bridge", "files.path", "ui.page", "ui.toast", "ui.input", "ui.theme"]
```

`mcp.bridge` 是红色的高危权限——因为它等于把文件、Shell、UI 自动化一整套交给插件。
其余五条都是界面 / 读路径这种低风险项。

**注意一个容易误解的点：** 拿到 `mcp.bridge` 就可以调 `fs_write`、`shell_exec`
这些工具，所以它在权限清单里被标成高危。申请它的时候用户会看到红色提示，这是故意的。

## 关键代码

```js
// 1. 拿名字（要先有 mcp.bridge，否则返回空数组）
var tools = ST.mcp.tools();

// 2. 调用。参数名就是工具 schema 里的参数名
ST.mcp.call('fs_list', { path: '/sdcard/Download' }, function (res) {
  if (res.error) {           // 权限不够 / 参数不对 / 宿主内部错误
    console.log(res.error);
    return;
  }
  if (res.isError) {         // 工具自己执行失败（比如路径不存在）
    console.log(res.text);
    return;
  }
  console.log(res.text);     // 正常结果，纯文本
});
```

## 常用工具与参数

| 工具 | 参数 | 说明 |
|---|---|---|
| `fs_list` | `path` | 列目录 |
| `fs_read` | `path`, `offset?`, `limit?` | 读文本，超过 256KB 会截断 |
| `fs_write` | `path`, `text` | 写文本 |
| `fs_stat` | `path` | 单个文件/目录详情 |
| `fs_search` | `path`, `keyword?` | 递归搜名字 |
| `fs_zip` / `fs_unzip` | `src`, `dst` | 压缩 / 解压 |
| `shell_exec` | `cmd`, `timeout?` | 执行 shell |
| `app_list` | `system?` | 已装应用列表 |
| `device_info` | — | 设备信息 |
| `clipboard_get` / `clipboard_set` | `text` | 剪贴板 |
| `toast` | `text` | 弹提示 |
| `ui_tap` / `ui_swipe` / `ui_screenshot` | 见工具 schema | 界面自动化 |

完整 30 个：`app_install app_launch app_list app_stop app_uninstall clipboard_get
clipboard_set device_info fs_delete fs_list fs_mkdir fs_move fs_read fs_search fs_stat
fs_unzip fs_write fs_zip logcat open_url shell_exec toast ui_dump ui_input ui_key
ui_long_press ui_screenshot ui_swipe ui_tap ui_wait`

## 想更进一步：注册自己的工具给 AI

`mcp.bridge` 同时也意味着「你可以成为工具提供方」。
把插件能力包装成 MCP 工具后，外部 AI 客户端就能发现并调用它——
这正是这个示例名字里「工具台」的意思：既能**用**工具，也能**供**工具。

具体做法见开发文档第 10 节。
