/*
 * MCP 工具台 —— 演示插件怎么调用宿主内置的 MCP 工具
 *
 * 关键点：
 *   ST.mcp.tools()                → ["fs_list","fs_read",...]（需要 mcp.bridge）
 *   ST.mcp.call(tool, args, cb)   → cb 收到 {ok:true, isError:false, text:"..."}
 *                                    失败时收到 {error:"原因"}
 *
 * 为什么值得用：这 30 个工具是宿主（和 AI）已经调好的能力，
 * 插件不用自己写一遍权限申请、路径校验、root 兜底。
 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var outEl = $('out');

  function hasST() {
    return !!(window.ST && typeof window.ST.api === 'number');
  }

  function show(title, body) {
    outEl.textContent = '── ' + title + ' ──\n' + body;
    outEl.scrollTop = 0;
  }

  function showObj(title, v) {
    var s;
    try { s = JSON.stringify(v, null, 2); } catch (e) { s = String(v); }
    show(title, s);
  }

  function needBridge() {
    if (!hasST()) { show('提示', '不在宿主里运行，没有 window.ST。'); return false; }
    if (!ST.mcp) { show('提示', '当前宿主版本没有 ST.mcp。'); return false; }
    if (!ST.hasPermission('mcp.bridge')) {
      show('缺少权限', 'mcp.bridge\n\n去 插件市场 → 本插件 → 权限 里授予「MCP 桥」后重试。');
      return false;
    }
    return true;
  }

  /** 让用户输入一个路径，默认用宿主当前目录 */
  function askPath(cb) {
    var def = (hasST() && ST.getPath) ? ST.getPath() : '';
    if (!def) def = '/sdcard';
    if (ST.input) {
      ST.input({ title: '输入要查询的路径', defaultValue: def, hint: '绝对路径' },
        function (v) {
          if (!v) { show('已取消', '没有输入路径。'); return; }
          cb(String(v));
        });
    } else {
      cb(def);
    }
  }

  // ------------------------------------------------------------------
  // ① 列工具
  // ------------------------------------------------------------------

  $('btnTools').addEventListener('click', function () {
    if (!needBridge()) return;
    var tools = ST.mcp.tools();
    if (!tools || !tools.length) { show('工具列表', '一个都没拿到（宿主 MCP 没启动？）'); return; }
    var lines = tools.map(function (n, i) {
      return '  ' + (i + 1 < 10 ? ' ' : '') + (i + 1) + '. ' + n;
    }).join('\n');
    show('共 ' + tools.length + ' 个工具', lines);
  });

  // ------------------------------------------------------------------
  // ② fs_list
  // ------------------------------------------------------------------

  $('btnList').addEventListener('click', function () {
    if (!needBridge()) return;
    askPath(function (path) {
      show('fs_list', '查询中：' + path + ' …');
      ST.mcp.call('fs_list', { path: path }, function (res) {
        if (!res) { show('fs_list', '没有返回'); return; }
        if (res.error) { show('fs_list 失败', res.error); return; }
        show('fs_list' + (res.isError ? '（工具报错）' : ''), res.text || '(空)');
      });
    });
  });

  // ------------------------------------------------------------------
  // ③ fs_stat
  // ------------------------------------------------------------------

  $('btnStat').addEventListener('click', function () {
    if (!needBridge()) return;
    askPath(function (path) {
      show('fs_stat', '查询中：' + path + ' …');
      ST.mcp.call('fs_stat', { path: path }, function (res) {
        if (!res) { show('fs_stat', '没有返回'); return; }
        if (res.error) { show('fs_stat 失败', res.error); return; }
        show('fs_stat', res.text || '(空)');
      });
    });
  });

  // ------------------------------------------------------------------
  // ④ device_info（无参数）
  // ------------------------------------------------------------------

  $('btnDev').addEventListener('click', function () {
    if (!needBridge()) return;
    show('device_info', '查询中…');
    ST.mcp.call('device_info', {}, function (res) {
      if (!res) { show('device_info', '没有返回'); return; }
      if (res.error) { show('device_info 失败', res.error); return; }
      show('device_info', res.text || '(空)');
    });
  });

  // ------------------------------------------------------------------
  // 主题 + 启动信息
  // ------------------------------------------------------------------

  (function applyTheme() {
    if (!hasST() || !ST.theme) return;
    var t = ST.theme, s = document.documentElement.style;
    if (t.bg) s.setProperty('--bg', t.bg);
    if (t.text) s.setProperty('--text', t.text);
    if (t.dim) s.setProperty('--dim', t.dim);
    if (t.surface) s.setProperty('--surface', t.surface);
    if (t.accent) s.setProperty('--accent', t.accent);
    s.setProperty('--line', t.isDark ? 'rgba(255,255,255,.10)' : 'rgba(0,0,0,.08)');
  })();

  if (hasST()) {
    var n = 0;
    try { n = (ST.mcp && ST.mcp.tools()) ? ST.mcp.tools().length : 0; } catch (e) { n = 0; }
    show('就绪', '宿主 API ' + ST.api +
      '\n插件：' + (ST.plugin ? ST.plugin.name + ' v' + ST.plugin.version : '?') +
      '\nmcp.bridge：' + (ST.hasPermission('mcp.bridge') ? '已授予' : '未授予') +
      '\n可用工具：' + n + ' 个');
  } else {
    show('提示', '没检测到 window.ST —— 你是在普通浏览器里打开的吧？');
  }
})();
